/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hashgui;

//custom exception for duplicate username
public class duplicateUsernameException extends Exception {//start of class

    duplicateUsernameException() {//start of exception
        //tell server the user input an incorrect action
        throw new UnsupportedOperationException("error user entered duplicate username.");

    }//end of exception
}//end of class

