package com.mycompany.hashgui;
//class that contains the user object aswell as the builder class
public class user {
   String username;
   private String password;
   private String salt;

   private user(String username, String password, String salt) {
      this.username = username;
      this.password = password;
      this.salt = salt;
   }

   public String getUsername() {
      return this.username;
   }
public String getSalt() {
      return this.salt;
   }
     public String getPassword() {
      return this.username;
   }
   @Override
   public String toString() {
      return "[ username: " + username + " password :" + password + " salt :" + salt + " ]";
   }
   public static class Builder {

    private String username;
    private String password;
    private String salt;

    public Builder setUsername(String username) {
        this.username = username;
        return this;
    }
      public String getUsername() {
      return this.username;
   }

    public Builder setPassword(String password) {
        this.password = password;
        return this;
    }

    public Builder setSalt(String salt) {
        this.salt = salt;
        return this;
    }
    
    public user build() {
        return new user(username, password, salt);
    }
}

}
